package com.jxx.esp.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.jxx.esp.model.Student;
import com.jxx.esp.model.VolActivity;
import com.jxx.esp.service.StudentService;
import com.jxx.esp.service.VolService;

@Controller
public class AppController {
	
	@Autowired
	VolService volSer;
	@Autowired
	StudentService stuSer;
	
	@GetMapping("/teacher/volunteer")
	public Object teacherVolunteer() {
		ArrayList<Student> students = stuSer.findAll();
		return students;
	}
	
	@GetMapping("/teacher/volunteer/details")
	public Object details(Long id) {
		Student stu = stuSer.getStuById(id);
		List<VolActivity> volActs = stu.getVols();
		return volActs;
	}
	

}
