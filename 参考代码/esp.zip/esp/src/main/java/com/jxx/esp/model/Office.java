package com.jxx.esp.model;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class Office {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String work;
	private String time;	
	
	@ManyToOne(cascade = {CascadeType.DETACH,CascadeType.PERSIST})
	private Student student;
	
	public Office() {
		super();
	}



	public Office(Long id, String work, String time, Student student) {
		super();
		this.id = id;
		this.work = work;
		this.time = time;
		this.student = student;
	}



	public Office(String work, String time, Student student) {
		super();
		this.work = work;
		this.time = time;
		this.student = student;
	}



	public Office(String work, String time) {
		super();
		this.work = work;
		this.time = time;
	}



	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}




	public String getWork() {
		return work;
	}


	public void setWork(String work) {
		this.work = work;
	}


	public String getTime() {
		return time;
	}


	public void setTime(String time) {
		this.time = time;
	}



	public Student getStudent() {
		return student;
	}



	public void setStudent(Student student) {
		this.student = student;
	}

	
	
}