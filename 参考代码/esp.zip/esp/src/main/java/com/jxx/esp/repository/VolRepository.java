package com.jxx.esp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jxx.esp.model.VolActivity;

@Repository
public interface VolRepository extends JpaRepository<VolActivity,Long>{
}
