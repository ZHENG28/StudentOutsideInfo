package com.jxx.esp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jxx.esp.repository.OfficeRepository;

@Service
public class OfficeService {
	@Autowired
	OfficeRepository officeRep;
}
