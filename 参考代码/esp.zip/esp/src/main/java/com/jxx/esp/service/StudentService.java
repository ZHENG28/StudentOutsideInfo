package com.jxx.esp.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jxx.esp.model.Student;
import com.jxx.esp.repository.StudentRepository;

@Service
public class StudentService {
	
	@Autowired
	StudentRepository studentRep;
	
	public ArrayList<Student> findAll(){
		
		
		return (ArrayList<Student>) studentRep.findAll();
		
	}
	
	public Student getStuById(Long id) {
		return studentRep.getById(id);
	}
	

}
