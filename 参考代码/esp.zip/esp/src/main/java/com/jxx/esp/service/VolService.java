package com.jxx.esp.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jxx.esp.model.VolActivity;
import com.jxx.esp.repository.VolRepository;

@Service
public class VolService {

	@Autowired
	VolRepository volRep;
	
	public ArrayList<VolActivity> findAll(){
		
		
		return (ArrayList<VolActivity>) volRep.findAll();
		
	}
}
